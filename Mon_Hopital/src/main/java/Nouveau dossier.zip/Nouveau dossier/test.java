import java.sql.SQLException;
import java.time.LocalDate;

public class test {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		/*String CNIE="14798";

		String nom="samir";
		String adresse = "123  Street";
		String telephone = "555-1234";
		String sexe = "M";
		int age = 30;
		String grpS = "A+";
		double qteSang = 450.0;
		LocalDate dateNaissance = LocalDate.of(2023, 11, 28);

		LocalDate dateDemande = LocalDate.now();
		//Demandeur demandeur = new Demandeur();
		Demandeur demandeur = new Demandeur(CNIE,nom, adresse, telephone,sexe, age, dateNaissance, grpS, qteSang, dateDemande);


		DemandeurImplements d=new DemandeurImplements();
		//d.add(demandeur);
		System.out.println("hi");

		//System.out.println(d.getOne(nom, dateNaissance));
		System.out.println(d.EtatDemande_Assuré());
		
		
		d.UpdateEtatDemande();
		System.out.println("hi");*/
		

		

	
		
		 // Création d'un objet Donneur pour le test
		
		
        //Donneur donneurTest = new Donneur("33", "John Doe", "Doe", "25", "70", "180",
                //LocalDate.of(1998, 5, 15), "O+", "600ml", "123 Main Street", "555-1234");

        // Création d'une instance de DonneurDaoImp
       /* DonneurDaoImp donneurDaoImp = new DonneurDaoImp();
        test1 test= new test1();
        // Appel de la méthode add pour ajouter le donneur
        test.add(donneurTest);*/
        //Login_users user= new Login_users();
        
        //System.out.println(user.getCentreID());
        //
		
		
		
        
    }
	

	
	

}
