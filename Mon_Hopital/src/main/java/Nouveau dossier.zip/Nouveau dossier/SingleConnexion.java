import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SingleConnexion {
    String db = "hôpital";
    String user = "root";
    String pwd = "rootroot";
    String url = "jdbc:mysql://localhost:3306/" + db;
    private static Connection connection = null;

    private SingleConnexion()  {
        System.out.println("Hi from SingleConnexion");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            connection = DriverManager.getConnection(url, user, pwd);
            System.out.println("Instance created successfully!!");
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Error hajar while creating the connection:");
            e.printStackTrace();
            System.out.println("erreur from SingleConnexion");

        }
    }

    public static Connection getConnection() {
        if (connection == null)
            new SingleConnexion();
        return connection;
    }
}
