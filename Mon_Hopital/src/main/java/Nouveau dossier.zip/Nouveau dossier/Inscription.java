import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.protobuf.Timestamp;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

@RequestScoped
@Named
public class Inscription {
	private Compte compte1=new Compte();
	private  List<Compte> listeComptesAdmin = new ArrayList<>();
	//private String CNIE;
	
	public Compte getCompte1() {
		return compte1;
	}

	public void setCompte1(Compte compte1) {
		this.compte1 = compte1;
		
	}
	public List<Compte> getListeComptesAdmin() {
        return listeComptesAdmin;
    }
		public void ajouter() {
		
		CompteIDAOimpl compteIDOA;
		try {
			System.out.println("hi from ajouter");
			 compteIDOA = new CompteIDAOimpl();
		     compteIDOA.add(compte1);
			 System.out.println("hi after ajouter");


		        // Vérifier si le compte a été ajouté avec succès avant de rafraîchir la liste
		       /* if (compteIDOA.getOne(compte1.getCNIE()) != null) {
		            // Rafraîchir la liste après l'ajout
		            //consulter();
			}*/
		}catch(Exception e) {
				throw e;
			}
		}
		
		
		
		
		private boolean validationRequired = true;
		
		public String consulter() {
		    CompteIDAOimpl compteIDOA;
		    try {
		        // Désactiver la validation pour la consultation
		        setValidationRequired(false);

		        compteIDOA = new CompteIDAOimpl();
		        // Appeler la méthode getAll() de la couche DAO pour obtenir tous les comptes
		        listeComptesAdmin = compteIDOA.getAll();
		        return "liste_compte.xhtml";
		    } catch (Exception e) {
		        throw e;
		    } finally {
		        // Réactiver la validation après la consultation
		        setValidationRequired(true);
		    }
		}

		public boolean isValidationRequired() {
			return validationRequired;
		}

		public void setValidationRequired(boolean validationRequired) {
			this.validationRequired = validationRequired;
		}
		
		
		
		private String CNIEToDelete;
		public String getCNIEToDelete() {
			return CNIEToDelete;
		}

		public void setCNIEToDelete(String cNIEToDelete) {
			CNIEToDelete = cNIEToDelete;
		}

		
		public void supprimer() {
		    CompteIDAOimpl compteIDOA;
		    try {
		        System.out.println("hi from Supprimer");
		        System.out.println("CNIE à supprimer : " + CNIEToDelete);

		        // Vérifier que CNIEToDelete n'est pas null avant de supprimer
		        if (CNIEToDelete != null) {
		            compteIDOA = new CompteIDAOimpl();
		            compteIDOA.delete(CNIEToDelete);

		            // Rafraîchir la liste après la suppression
		            consulter();
		        } else {
		            System.out.println("Avertissement : Tentative de suppression avec CNIEToDelete null.");
		        }
		    } catch (Exception e) {
		        throw e;
		    }
		}
		
		public void modifier() {
		    CompteIDAOimpl compteIDOA;
		    try {
		    	
		        compteIDOA = new CompteIDAOimpl();
		        compteIDOA.update(compte1);

		        // Rafraîchir la liste après la modification
		        consulter();
		    } catch (Exception e) {
		        throw e;
		    }
		}
		

		
		
		
		
		private Map<String, Compte> compteDetails = new HashMap<>();

		public Map<String, Compte> getCompteDetails() {
		    return compteDetails;
		}

		public void setCompteDetails(Map<String, Compte> compteDetails) {
		    this.compteDetails = compteDetails;
		}
		
		private Compte selectedAccount;
		

		 public Compte getSelectedAccount() {
		        return selectedAccount;
		    }
		    public void setSelectedAccount(Compte selectedAccount) {
		        this.selectedAccount = selectedAccount;
		    }
		    public String afficherDetails() {
		        try {
		            // Utilisez la méthode afficherDetails de CompteIDAOimpl avec le CNIE saisi
		            CompteIDAOimpl compteIDAO = new CompteIDAOimpl();
		            Compte compte = compteIDAO.getByCNIE(CNIEToDisplay);
		            System.out.println(compte);

		            if (compte != null) {
		                // Stockez les détails du compte dans la carte avec le CNIE comme clé
		                compteDetails.put(CNIEToDisplay, compte);
		                return "details.xhtml";
		            } else {
		                // Le compte n'a pas été trouvé, vous pouvez gérer cela comme vous le souhaitez
		                return "error.xhtml"; // ou une autre chaîne de navigation appropriée
		            }
		        } catch (Exception e) {
		            // Gérer les erreurs
		            e.printStackTrace();
		            return "error.xhtml"; // ou une autre chaîne de navigation appropriée
		        }
		    }

		
		private String CNIEToDisplay; // Nouvelle propriété pour stocker le CNIE saisi

	    public String getCNIEToDisplay() {
	        return CNIEToDisplay;
	    }

	    public void setCNIEToDisplay(String CNIEToDisplay) {
	        this.CNIEToDisplay = CNIEToDisplay;
	    }

	  
	
}
