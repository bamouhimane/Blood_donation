
public interface DonneurDAO extends IDAO<Donneur>{

	

}
