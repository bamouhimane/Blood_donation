
public interface DemandeurDAO extends IDAO<Demandeur> {

}
